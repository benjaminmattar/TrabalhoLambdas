public enum Departamento {
    VENDAS, FINANCEIRO, GERENCIA
}
